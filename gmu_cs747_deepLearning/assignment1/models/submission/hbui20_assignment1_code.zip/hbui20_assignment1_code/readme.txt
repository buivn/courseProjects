Assignment 1 - CS747 
Hoang-Dung Bui
G01301478
Team Name on Kaggle Leaderboard: Hoang-Dung Bui

I added the data loading functions from data_process.py module into my code. So, the codes does not need the data_process.py model.

- To call the Perception algorithm, just type python3 perceptron.py

- To call the svm algorithm, just type: python3 svm.py

- To call the softmax algorithm, just type python3 Softmax.py


I also tried to complete the Bonus Point part with two codes:
- To call the extra1 algorithm (bonus point), just type python3 svm_extra_1.py
- To call the extra2 algorithm (bonus point), just type python3 svm_extra_2.py


I strictly follow the formulas on the lecture slides to write my codes, however, I don't know why my algorithm provides very low accuracy (highest is 0.302) comparing with the benchmark.

